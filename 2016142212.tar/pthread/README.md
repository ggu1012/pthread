# pthread
Mandelbrot set calculation with multiple thread.

Display mandelbrot set with OpenGL.
